import ipinfo
import csv
from flask import Flask, render_template, request, session, redirect, url_for
import os

from flask import Flask, request, render_template, redirect, url_for, send_from_directory
from werkzeug.utils import secure_filename
from datetime import datetime


app = Flask(__name__)

UPLOAD_FOLDER = "D:\\ip_mapping\\Flask-Web-App-IP-Address\\uploads"

# upload directory file config
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def getloc(ip):
    access_token = 'e7b96a2a6d1cd4'
    handler = ipinfo.getHandler(access_token)
    ip_address = ip
    try:
        details = handler.getDetails(ip_address)
        return details.all
    except:
        return {}


app.secret_key = "fiu"


@app.route("/")
def home(): 
    return render_template('home.html')

@app.route("/SingleSearch", methods=['GET', 'POST'])
def SingleSearch():
    city = ''
    state = ''
    d = {}
    lat = 0.0
    lon = 0.0
    if request.method == 'POST':
        session['ip'] = request.form.get('ip')
        d = getloc(session['ip'])
        if d:
            lat = d['latitude']
            lon = d['longitude']
            
    return render_template('index.html', ip=session['ip'] if 'ip' in session else None,
                           ifInvalid='Invalid IP' if not d else '', list=d, lat=lat, lon=lon)

@app.route("/MultipleSearch", methods=['GET', 'POST'])
def upload():
    if request.method == 'POST':
        file = request.files['file']
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            new_filename = f'{filename.split(".")[0]}_{str(datetime.now())}.csv'
            save_location = os.path.join('input', new_filename)
            file.save(save_location)
    return render_template('index_2.html')

if __name__ == "__main__":
    app.run(debug = True)